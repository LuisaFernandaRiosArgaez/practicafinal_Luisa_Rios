﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace taller_final_Herramientas
{
    public partial class Postres : Form
    {


        public Postres()
        {
            InitializeComponent();
        }

        private void btnAgregarPostres_Click(object sender, EventArgs e)
        {
           decimal cantidadp, valorunidadp, valortotalp, valortotalpagarp = 0;
           string nombreproductop="";

            if (ndTiramisu.Value > 0)
            {

                nombreproductop += lblTiramisú.Text + ", \r\n";
                txtvalorunidadp.Text += lblPrecioTiramisu.Text + ", \r\n";
                valorunidadp = Convert.ToDecimal(lblPrecioTiramisu.Text);
                valortotalp = valorunidadp * ndTiramisu.Value;
                valortotalpagarp = valortotalpagarp + valortotalp;
                cantidadp = ndTiramisu.Value;
                txtcantidadp.Text += cantidadp.ToString() + ", \r\n";
                txtvalortotalp.Text += valortotalp.ToString() + ", \r\n";
            }



            if (ndGalleta.Value > 0)
            {

                nombreproductop += lblGalleta.Text + ", \r\n";
                txtvalorunidadp.Text += lblPrecioGalleta.Text + ", \r\n";
                valorunidadp = Convert.ToDecimal(lblPrecioGalleta.Text);
                valortotalp = valorunidadp * ndGalleta.Value;
                valortotalpagarp = valortotalpagarp + valortotalp;
                cantidadp = ndGalleta.Value;
                txtcantidadp.Text += cantidadp.ToString() + ", \r\n";
                txtvalortotalp.Text += valortotalp.ToString() + ", \r\n";
            }

            if (ndTartaleta.Value > 0)
            {

                nombreproductop += lblTartaleta.Text + ", \r\n";
                txtvalorunidadp.Text += lblPrecioTartaleta.Text + ", \r\n";
                valorunidadp = Convert.ToDecimal(lblPrecioTartaleta.Text);
                valortotalp = valorunidadp * ndTartaleta.Value;
                valortotalpagarp = valortotalpagarp + valortotalp;
                cantidadp = ndTartaleta.Value;
                txtcantidadp.Text += cantidadp.ToString() + ", \r\n";
                txtvalortotalp.Text += valortotalp.ToString() + ", \r\n";
            }


            if (ndBrownie.Value > 0)
                {

                nombreproductop += lblBrownie.Text + ", \r\n";
                txtvalorunidadp.Text += lblPrecioBrownie.Text + ", \r\n";
                valorunidadp = Convert.ToDecimal(lblPrecioBrownie.Text);
                valortotalp = valorunidadp * ndBrownie.Value;
                valortotalpagarp = valortotalpagarp + valortotalp;
                cantidadp = ndBrownie.Value;
                txtcantidadp.Text += cantidadp.ToString() + ", \r\n";
                txtvalortotalp.Text += valortotalp.ToString() + ", \r\n";
                }

            if (ndCheesecake.Value > 0)
            {

                nombreproductop += lblCheesecake.Text + ", \r\n";
                txtvalorunidadp.Text += lblPrecioCheesecake.Text + ", \r\n";
                valorunidadp = Convert.ToDecimal(lblPrecioCheesecake.Text);
                valortotalp = valorunidadp * ndCheesecake.Value;
                valortotalpagarp = valortotalpagarp + valortotalp;
                cantidadp = ndCheesecake.Value;
                txtcantidadp.Text += cantidadp.ToString() + ", \r\n";
                txtvalortotalp.Text += valortotalp.ToString() + ", \r\n";
            }

            txtnombrep.Text = nombreproductop;
            txttotalpagarp.Text = valortotalpagarp.ToString();


            Menu mi_menu = new Menu();
            mi_menu.Nombreproductom = txtnombrep.Text;
            mi_menu.Cantidadm = txtcantidadp.Text;
            mi_menu.Valorunidadm = txtvalorunidadp.Text;
            mi_menu.Valortotalm = txtvalortotalp.Text;



        }
    }
}
