﻿namespace taller_final_Herramientas
{
    partial class Plato_fuerte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Plato_fuerte));
            this.btnAgregarPlatoFuerte = new System.Windows.Forms.Button();
            this.ndRisottoCarbonara = new System.Windows.Forms.NumericUpDown();
            this.ndPastaAlfredoconSalmón = new System.Windows.Forms.NumericUpDown();
            this.ndPastaCarbonara = new System.Windows.Forms.NumericUpDown();
            this.ndLasagnaVegetariana = new System.Windows.Forms.NumericUpDown();
            this.ndPastadelaHuerta = new System.Windows.Forms.NumericUpDown();
            this.lblPrecioPastadelaHuerta = new System.Windows.Forms.Label();
            this.lblPrecioLasagnaVegetariana = new System.Windows.Forms.Label();
            this.lblPrecioPastaCarbonara = new System.Windows.Forms.Label();
            this.lblPrecioPastaAlfredoconSalmón = new System.Windows.Forms.Label();
            this.lblPrecioRisottoCarbonara = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblPastadelaHuerta = new System.Windows.Forms.Label();
            this.lblLasagnaVegetariana = new System.Windows.Forms.Label();
            this.lblPastaCarbonara = new System.Windows.Forms.Label();
            this.lblPastaAlfredoconSalmón = new System.Windows.Forms.Label();
            this.lblRisottoCarbonara = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtnom = new System.Windows.Forms.TextBox();
            this.txtcant = new System.Windows.Forms.TextBox();
            this.txtvaloru = new System.Windows.Forms.TextBox();
            this.txtvalort = new System.Windows.Forms.TextBox();
            this.txttotalp = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.ndRisottoCarbonara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndPastaAlfredoconSalmón)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndPastaCarbonara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndLasagnaVegetariana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndPastadelaHuerta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAgregarPlatoFuerte
            // 
            this.btnAgregarPlatoFuerte.Location = new System.Drawing.Point(522, 280);
            this.btnAgregarPlatoFuerte.Name = "btnAgregarPlatoFuerte";
            this.btnAgregarPlatoFuerte.Size = new System.Drawing.Size(135, 46);
            this.btnAgregarPlatoFuerte.TabIndex = 95;
            this.btnAgregarPlatoFuerte.Text = "Agregar al carrito";
            this.btnAgregarPlatoFuerte.UseVisualStyleBackColor = true;
            this.btnAgregarPlatoFuerte.Click += new System.EventHandler(this.btnAgregarPlatoFuerte_Click);
            // 
            // ndRisottoCarbonara
            // 
            this.ndRisottoCarbonara.Location = new System.Drawing.Point(160, 198);
            this.ndRisottoCarbonara.Name = "ndRisottoCarbonara";
            this.ndRisottoCarbonara.Size = new System.Drawing.Size(37, 20);
            this.ndRisottoCarbonara.TabIndex = 94;
            // 
            // ndPastaAlfredoconSalmón
            // 
            this.ndPastaAlfredoconSalmón.Location = new System.Drawing.Point(400, 198);
            this.ndPastaAlfredoconSalmón.Name = "ndPastaAlfredoconSalmón";
            this.ndPastaAlfredoconSalmón.Size = new System.Drawing.Size(37, 20);
            this.ndPastaAlfredoconSalmón.TabIndex = 93;
            // 
            // ndPastaCarbonara
            // 
            this.ndPastaCarbonara.Location = new System.Drawing.Point(663, 198);
            this.ndPastaCarbonara.Name = "ndPastaCarbonara";
            this.ndPastaCarbonara.Size = new System.Drawing.Size(37, 20);
            this.ndPastaCarbonara.TabIndex = 92;
            // 
            // ndLasagnaVegetariana
            // 
            this.ndLasagnaVegetariana.Location = new System.Drawing.Point(155, 394);
            this.ndLasagnaVegetariana.Name = "ndLasagnaVegetariana";
            this.ndLasagnaVegetariana.Size = new System.Drawing.Size(37, 20);
            this.ndLasagnaVegetariana.TabIndex = 91;
            // 
            // ndPastadelaHuerta
            // 
            this.ndPastadelaHuerta.Location = new System.Drawing.Point(403, 394);
            this.ndPastadelaHuerta.Name = "ndPastadelaHuerta";
            this.ndPastadelaHuerta.Size = new System.Drawing.Size(37, 20);
            this.ndPastadelaHuerta.TabIndex = 90;
            // 
            // lblPrecioPastadelaHuerta
            // 
            this.lblPrecioPastadelaHuerta.AutoSize = true;
            this.lblPrecioPastadelaHuerta.Location = new System.Drawing.Point(400, 345);
            this.lblPrecioPastadelaHuerta.Name = "lblPrecioPastadelaHuerta";
            this.lblPrecioPastadelaHuerta.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioPastadelaHuerta.TabIndex = 89;
            this.lblPrecioPastadelaHuerta.Text = "30900";
            // 
            // lblPrecioLasagnaVegetariana
            // 
            this.lblPrecioLasagnaVegetariana.AutoSize = true;
            this.lblPrecioLasagnaVegetariana.Location = new System.Drawing.Point(157, 345);
            this.lblPrecioLasagnaVegetariana.Name = "lblPrecioLasagnaVegetariana";
            this.lblPrecioLasagnaVegetariana.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioLasagnaVegetariana.TabIndex = 88;
            this.lblPrecioLasagnaVegetariana.Text = "27900";
            // 
            // lblPrecioPastaCarbonara
            // 
            this.lblPrecioPastaCarbonara.AutoSize = true;
            this.lblPrecioPastaCarbonara.Location = new System.Drawing.Point(663, 151);
            this.lblPrecioPastaCarbonara.Name = "lblPrecioPastaCarbonara";
            this.lblPrecioPastaCarbonara.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioPastaCarbonara.TabIndex = 87;
            this.lblPrecioPastaCarbonara.Text = "37900";
            // 
            // lblPrecioPastaAlfredoconSalmón
            // 
            this.lblPrecioPastaAlfredoconSalmón.AutoSize = true;
            this.lblPrecioPastaAlfredoconSalmón.Location = new System.Drawing.Point(400, 151);
            this.lblPrecioPastaAlfredoconSalmón.Name = "lblPrecioPastaAlfredoconSalmón";
            this.lblPrecioPastaAlfredoconSalmón.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioPastaAlfredoconSalmón.TabIndex = 86;
            this.lblPrecioPastaAlfredoconSalmón.Text = "37900";
            // 
            // lblPrecioRisottoCarbonara
            // 
            this.lblPrecioRisottoCarbonara.AutoSize = true;
            this.lblPrecioRisottoCarbonara.Location = new System.Drawing.Point(162, 151);
            this.lblPrecioRisottoCarbonara.Name = "lblPrecioRisottoCarbonara";
            this.lblPrecioRisottoCarbonara.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioRisottoCarbonara.TabIndex = 85;
            this.lblPrecioRisottoCarbonara.Text = "36600";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(251, 345);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(143, 69);
            this.textBox5.TabIndex = 84;
            this.textBox5.Text = "Pasta de la huerta salteada con pesto, brócoli, tomates cherris acompañada de pan" +
    " baguette.";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(11, 345);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(143, 69);
            this.textBox4.TabIndex = 83;
            this.textBox4.Text = "Lasagna de vegetariana mix de vegetales salteados con reducción balsámica y grati" +
    "nada en el horno acompañada de pan baguette";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(514, 149);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(143, 69);
            this.textBox3.TabIndex = 82;
            this.textBox3.Text = "Tradicional salsa cremosa a base de tocineta ahumada y vino blanco, escamas de qu" +
    "eso parmesano, pan fresco.";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(251, 149);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(143, 69);
            this.textBox2.TabIndex = 81;
            this.textBox2.Text = "Salmón fresco, salsa a base de crema y vino blanco, escamas de queso parmesano, p" +
    "an fresco.";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(11, 149);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(143, 69);
            this.textBox1.TabIndex = 80;
            this.textBox1.Text = "Tradicional risotto de la casa, a base de tocineta, vino blanco, queso parmesano," +
    " frutos secos y brotes orgánicos.";
            // 
            // lblPastadelaHuerta
            // 
            this.lblPastadelaHuerta.AutoSize = true;
            this.lblPastadelaHuerta.Location = new System.Drawing.Point(248, 232);
            this.lblPastadelaHuerta.Name = "lblPastadelaHuerta";
            this.lblPastadelaHuerta.Size = new System.Drawing.Size(95, 13);
            this.lblPastadelaHuerta.TabIndex = 79;
            this.lblPastadelaHuerta.Text = "Pasta de la Huerta";
            // 
            // lblLasagnaVegetariana
            // 
            this.lblLasagnaVegetariana.AutoSize = true;
            this.lblLasagnaVegetariana.Location = new System.Drawing.Point(8, 232);
            this.lblLasagnaVegetariana.Name = "lblLasagnaVegetariana";
            this.lblLasagnaVegetariana.Size = new System.Drawing.Size(108, 13);
            this.lblLasagnaVegetariana.TabIndex = 78;
            this.lblLasagnaVegetariana.Text = "Lasagna Vegetariana";
            // 
            // lblPastaCarbonara
            // 
            this.lblPastaCarbonara.AutoSize = true;
            this.lblPastaCarbonara.Location = new System.Drawing.Point(511, 68);
            this.lblPastaCarbonara.Name = "lblPastaCarbonara";
            this.lblPastaCarbonara.Size = new System.Drawing.Size(86, 13);
            this.lblPastaCarbonara.TabIndex = 77;
            this.lblPastaCarbonara.Text = "Pasta Carbonara";
            // 
            // lblPastaAlfredoconSalmón
            // 
            this.lblPastaAlfredoconSalmón.AutoSize = true;
            this.lblPastaAlfredoconSalmón.Location = new System.Drawing.Point(252, 59);
            this.lblPastaAlfredoconSalmón.Name = "lblPastaAlfredoconSalmón";
            this.lblPastaAlfredoconSalmón.Size = new System.Drawing.Size(129, 13);
            this.lblPastaAlfredoconSalmón.TabIndex = 76;
            this.lblPastaAlfredoconSalmón.Text = "Pasta Alfredo con Salmón";
            // 
            // lblRisottoCarbonara
            // 
            this.lblRisottoCarbonara.AutoSize = true;
            this.lblRisottoCarbonara.Location = new System.Drawing.Point(11, 59);
            this.lblRisottoCarbonara.Name = "lblRisottoCarbonara";
            this.lblRisottoCarbonara.Size = new System.Drawing.Size(92, 13);
            this.lblRisottoCarbonara.TabIndex = 75;
            this.lblRisottoCarbonara.Text = "Risotto Carbonara";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(11, 248);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(139, 91);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 74;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(251, 75);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(143, 77);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 73;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(514, 84);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(143, 68);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 72;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(251, 248);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(143, 91);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 71;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(11, 75);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(139, 77);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 70;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(828, 497);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 69;
            this.pictureBox1.TabStop = false;
            // 
            // txtnom
            // 
            this.txtnom.Location = new System.Drawing.Point(468, 344);
            this.txtnom.Name = "txtnom";
            this.txtnom.Size = new System.Drawing.Size(78, 20);
            this.txtnom.TabIndex = 96;
            this.txtnom.TextChanged += new System.EventHandler(this.txtnom_TextChanged);
            // 
            // txtcant
            // 
            this.txtcant.Location = new System.Drawing.Point(552, 344);
            this.txtcant.Name = "txtcant";
            this.txtcant.Size = new System.Drawing.Size(78, 20);
            this.txtcant.TabIndex = 97;
            this.txtcant.TextChanged += new System.EventHandler(this.txtcant_TextChanged);
            // 
            // txtvaloru
            // 
            this.txtvaloru.Location = new System.Drawing.Point(635, 344);
            this.txtvaloru.Name = "txtvaloru";
            this.txtvaloru.Size = new System.Drawing.Size(78, 20);
            this.txtvaloru.TabIndex = 98;
            this.txtvaloru.TextChanged += new System.EventHandler(this.txtvaloru_TextChanged);
            // 
            // txtvalort
            // 
            this.txtvalort.Location = new System.Drawing.Point(718, 344);
            this.txtvalort.Name = "txtvalort";
            this.txtvalort.Size = new System.Drawing.Size(78, 20);
            this.txtvalort.TabIndex = 99;
            this.txtvalort.TextChanged += new System.EventHandler(this.txtvalort_TextChanged);
            // 
            // txttotalp
            // 
            this.txttotalp.Location = new System.Drawing.Point(718, 404);
            this.txttotalp.Name = "txttotalp";
            this.txttotalp.Size = new System.Drawing.Size(78, 20);
            this.txttotalp.TabIndex = 100;
            this.txttotalp.TextChanged += new System.EventHandler(this.txttotalp_TextChanged);
            // 
            // Plato_fuerte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 467);
            this.Controls.Add(this.txttotalp);
            this.Controls.Add(this.txtvalort);
            this.Controls.Add(this.txtvaloru);
            this.Controls.Add(this.txtcant);
            this.Controls.Add(this.txtnom);
            this.Controls.Add(this.btnAgregarPlatoFuerte);
            this.Controls.Add(this.ndRisottoCarbonara);
            this.Controls.Add(this.ndPastaAlfredoconSalmón);
            this.Controls.Add(this.ndPastaCarbonara);
            this.Controls.Add(this.ndLasagnaVegetariana);
            this.Controls.Add(this.ndPastadelaHuerta);
            this.Controls.Add(this.lblPrecioPastadelaHuerta);
            this.Controls.Add(this.lblPrecioLasagnaVegetariana);
            this.Controls.Add(this.lblPrecioPastaCarbonara);
            this.Controls.Add(this.lblPrecioPastaAlfredoconSalmón);
            this.Controls.Add(this.lblPrecioRisottoCarbonara);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblPastadelaHuerta);
            this.Controls.Add(this.lblLasagnaVegetariana);
            this.Controls.Add(this.lblPastaCarbonara);
            this.Controls.Add(this.lblPastaAlfredoconSalmón);
            this.Controls.Add(this.lblRisottoCarbonara);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Plato_fuerte";
            this.Text = "Plato_fuerte";
            this.Load += new System.EventHandler(this.Plato_fuerte_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ndRisottoCarbonara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndPastaAlfredoconSalmón)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndPastaCarbonara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndLasagnaVegetariana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndPastadelaHuerta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAgregarPlatoFuerte;
        private System.Windows.Forms.NumericUpDown ndRisottoCarbonara;
        private System.Windows.Forms.NumericUpDown ndPastaAlfredoconSalmón;
        private System.Windows.Forms.NumericUpDown ndPastaCarbonara;
        private System.Windows.Forms.NumericUpDown ndLasagnaVegetariana;
        private System.Windows.Forms.NumericUpDown ndPastadelaHuerta;
        private System.Windows.Forms.Label lblPrecioPastadelaHuerta;
        private System.Windows.Forms.Label lblPrecioLasagnaVegetariana;
        private System.Windows.Forms.Label lblPrecioPastaCarbonara;
        private System.Windows.Forms.Label lblPrecioPastaAlfredoconSalmón;
        private System.Windows.Forms.Label lblPrecioRisottoCarbonara;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblPastadelaHuerta;
        private System.Windows.Forms.Label lblLasagnaVegetariana;
        private System.Windows.Forms.Label lblPastaCarbonara;
        private System.Windows.Forms.Label lblPastaAlfredoconSalmón;
        private System.Windows.Forms.Label lblRisottoCarbonara;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtnom;
        private System.Windows.Forms.TextBox txtcant;
        private System.Windows.Forms.TextBox txtvaloru;
        private System.Windows.Forms.TextBox txtvalort;
        private System.Windows.Forms.TextBox txttotalp;
    }
}