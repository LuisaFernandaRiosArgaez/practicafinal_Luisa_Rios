﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace taller_final_Herramientas
{
    public partial class Carrito : Form
    {
        public string cantidadc, valorunidadc, valortotalc, nombreproductoc;

        public Carrito()
        {
            InitializeComponent();
        }

        public string Nombreproductoc
        {
            set
            {
                nombreproductoc = value;
                txtnombre.Text = nombreproductoc;
            }

        }

        public string Cantidadc
        {
            set
            {
                cantidadc = value;
                txtcantidad.Text = cantidadc;
            }
        }

        private void txtnombre_TextChanged(object sender, EventArgs e)
        {
            txtnombre.Text = nombreproductoc;

        }

        public string Valorunidadc
        {
            set
            {
                valorunidadc = value;
                txtcantidad.Text = valorunidadc;
            }
        }
        public string Valortotalc
        {
            set
            {
                valortotalc = value;
                txtcantidad.Text = valortotalc;
            }
        }


        private void Carrito_Load(object sender, EventArgs e)
        {
            txtnombre.Text= nombreproductoc;
            txtcantidad.Text = cantidadc;
            txtvalorunidad.Text = valorunidadc;
            txttotal.Text = valortotalc;

        }
        
    }
}
