﻿namespace taller_final_Herramientas
{
    partial class Bebidas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bebidas));
            this.btnAgregarBebidas = new System.Windows.Forms.Button();
            this.ndCocacola = new System.Windows.Forms.NumericUpDown();
            this.ndLimoncello = new System.Windows.Forms.NumericUpDown();
            this.ndJugodePiñaconHierbabuena = new System.Windows.Forms.NumericUpDown();
            this.ndJugodeFrutosAmarillos = new System.Windows.Forms.NumericUpDown();
            this.ndJugodeFrutosRojos = new System.Windows.Forms.NumericUpDown();
            this.lblPrecioJugodeFrutosRojos = new System.Windows.Forms.Label();
            this.lblPrecioJugodeFrutosAmarillos = new System.Windows.Forms.Label();
            this.lblPrecioJugodePiñaconHierbabuena = new System.Windows.Forms.Label();
            this.lblPrecioLimoncello = new System.Windows.Forms.Label();
            this.lblPrecioGaseosaCocaColaSinAzucar = new System.Windows.Forms.Label();
            this.lblJugodeFrutosRojos = new System.Windows.Forms.Label();
            this.lblJugodeFrutosAmarillos = new System.Windows.Forms.Label();
            this.lblJugodePiñaconHierbabuena = new System.Windows.Forms.Label();
            this.lblLimoncello = new System.Windows.Forms.Label();
            this.lblGaseosaCocaColaSinAzucar300ml = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtnombreb = new System.Windows.Forms.TextBox();
            this.txtvalortotalb = new System.Windows.Forms.TextBox();
            this.txtvalorunidadb = new System.Windows.Forms.TextBox();
            this.txtcantidadb = new System.Windows.Forms.TextBox();
            this.txttotalapagare = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.ndCocacola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndLimoncello)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndJugodePiñaconHierbabuena)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndJugodeFrutosAmarillos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndJugodeFrutosRojos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAgregarBebidas
            // 
            this.btnAgregarBebidas.Location = new System.Drawing.Point(577, 337);
            this.btnAgregarBebidas.Name = "btnAgregarBebidas";
            this.btnAgregarBebidas.Size = new System.Drawing.Size(146, 56);
            this.btnAgregarBebidas.TabIndex = 90;
            this.btnAgregarBebidas.Text = "Agregar al carito ";
            this.btnAgregarBebidas.UseVisualStyleBackColor = true;
            this.btnAgregarBebidas.Click += new System.EventHandler(this.btnAgregarBebidas_Click);
            // 
            // ndCocacola
            // 
            this.ndCocacola.Location = new System.Drawing.Point(251, 186);
            this.ndCocacola.Name = "ndCocacola";
            this.ndCocacola.Size = new System.Drawing.Size(37, 20);
            this.ndCocacola.TabIndex = 89;
            // 
            // ndLimoncello
            // 
            this.ndLimoncello.Location = new System.Drawing.Point(484, 186);
            this.ndLimoncello.Name = "ndLimoncello";
            this.ndLimoncello.Size = new System.Drawing.Size(37, 20);
            this.ndLimoncello.TabIndex = 88;
            // 
            // ndJugodePiñaconHierbabuena
            // 
            this.ndJugodePiñaconHierbabuena.Location = new System.Drawing.Point(732, 186);
            this.ndJugodePiñaconHierbabuena.Name = "ndJugodePiñaconHierbabuena";
            this.ndJugodePiñaconHierbabuena.Size = new System.Drawing.Size(37, 20);
            this.ndJugodePiñaconHierbabuena.TabIndex = 87;
            // 
            // ndJugodeFrutosAmarillos
            // 
            this.ndJugodeFrutosAmarillos.Location = new System.Drawing.Point(248, 393);
            this.ndJugodeFrutosAmarillos.Name = "ndJugodeFrutosAmarillos";
            this.ndJugodeFrutosAmarillos.Size = new System.Drawing.Size(37, 20);
            this.ndJugodeFrutosAmarillos.TabIndex = 86;
            // 
            // ndJugodeFrutosRojos
            // 
            this.ndJugodeFrutosRojos.Location = new System.Drawing.Point(486, 393);
            this.ndJugodeFrutosRojos.Name = "ndJugodeFrutosRojos";
            this.ndJugodeFrutosRojos.Size = new System.Drawing.Size(37, 20);
            this.ndJugodeFrutosRojos.TabIndex = 85;
            // 
            // lblPrecioJugodeFrutosRojos
            // 
            this.lblPrecioJugodeFrutosRojos.AutoSize = true;
            this.lblPrecioJugodeFrutosRojos.Location = new System.Drawing.Point(486, 271);
            this.lblPrecioJugodeFrutosRojos.Name = "lblPrecioJugodeFrutosRojos";
            this.lblPrecioJugodeFrutosRojos.Size = new System.Drawing.Size(31, 13);
            this.lblPrecioJugodeFrutosRojos.TabIndex = 84;
            this.lblPrecioJugodeFrutosRojos.Text = "8500";
            // 
            // lblPrecioJugodeFrutosAmarillos
            // 
            this.lblPrecioJugodeFrutosAmarillos.AutoSize = true;
            this.lblPrecioJugodeFrutosAmarillos.Location = new System.Drawing.Point(245, 271);
            this.lblPrecioJugodeFrutosAmarillos.Name = "lblPrecioJugodeFrutosAmarillos";
            this.lblPrecioJugodeFrutosAmarillos.Size = new System.Drawing.Size(31, 13);
            this.lblPrecioJugodeFrutosAmarillos.TabIndex = 83;
            this.lblPrecioJugodeFrutosAmarillos.Text = "8500";
            // 
            // lblPrecioJugodePiñaconHierbabuena
            // 
            this.lblPrecioJugodePiñaconHierbabuena.AutoSize = true;
            this.lblPrecioJugodePiñaconHierbabuena.Location = new System.Drawing.Point(729, 107);
            this.lblPrecioJugodePiñaconHierbabuena.Name = "lblPrecioJugodePiñaconHierbabuena";
            this.lblPrecioJugodePiñaconHierbabuena.Size = new System.Drawing.Size(31, 13);
            this.lblPrecioJugodePiñaconHierbabuena.TabIndex = 82;
            this.lblPrecioJugodePiñaconHierbabuena.Text = "8100";
            // 
            // lblPrecioLimoncello
            // 
            this.lblPrecioLimoncello.AutoSize = true;
            this.lblPrecioLimoncello.Location = new System.Drawing.Point(486, 98);
            this.lblPrecioLimoncello.Name = "lblPrecioLimoncello";
            this.lblPrecioLimoncello.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioLimoncello.TabIndex = 81;
            this.lblPrecioLimoncello.Text = "17900";
            // 
            // lblPrecioGaseosaCocaColaSinAzucar
            // 
            this.lblPrecioGaseosaCocaColaSinAzucar.AutoSize = true;
            this.lblPrecioGaseosaCocaColaSinAzucar.Location = new System.Drawing.Point(248, 98);
            this.lblPrecioGaseosaCocaColaSinAzucar.Name = "lblPrecioGaseosaCocaColaSinAzucar";
            this.lblPrecioGaseosaCocaColaSinAzucar.Size = new System.Drawing.Size(31, 13);
            this.lblPrecioGaseosaCocaColaSinAzucar.TabIndex = 80;
            this.lblPrecioGaseosaCocaColaSinAzucar.Text = "5900";
            // 
            // lblJugodeFrutosRojos
            // 
            this.lblJugodeFrutosRojos.AutoSize = true;
            this.lblJugodeFrutosRojos.Location = new System.Drawing.Point(296, 255);
            this.lblJugodeFrutosRojos.Name = "lblJugodeFrutosRojos";
            this.lblJugodeFrutosRojos.Size = new System.Drawing.Size(107, 13);
            this.lblJugodeFrutosRojos.TabIndex = 79;
            this.lblJugodeFrutosRojos.Text = "Jugo de Frutos Rojos";
            // 
            // lblJugodeFrutosAmarillos
            // 
            this.lblJugodeFrutosAmarillos.AutoSize = true;
            this.lblJugodeFrutosAmarillos.Location = new System.Drawing.Point(56, 255);
            this.lblJugodeFrutosAmarillos.Name = "lblJugodeFrutosAmarillos";
            this.lblJugodeFrutosAmarillos.Size = new System.Drawing.Size(121, 13);
            this.lblJugodeFrutosAmarillos.TabIndex = 78;
            this.lblJugodeFrutosAmarillos.Text = "Jugo de Frutos Amarillos";
            // 
            // lblJugodePiñaconHierbabuena
            // 
            this.lblJugodePiñaconHierbabuena.AutoSize = true;
            this.lblJugodePiñaconHierbabuena.Location = new System.Drawing.Point(556, 82);
            this.lblJugodePiñaconHierbabuena.Name = "lblJugodePiñaconHierbabuena";
            this.lblJugodePiñaconHierbabuena.Size = new System.Drawing.Size(154, 13);
            this.lblJugodePiñaconHierbabuena.TabIndex = 77;
            this.lblJugodePiñaconHierbabuena.Text = "Jugo de Piña con Hierbabuena";
            // 
            // lblLimoncello
            // 
            this.lblLimoncello.AutoSize = true;
            this.lblLimoncello.Location = new System.Drawing.Point(300, 82);
            this.lblLimoncello.Name = "lblLimoncello";
            this.lblLimoncello.Size = new System.Drawing.Size(57, 13);
            this.lblLimoncello.TabIndex = 76;
            this.lblLimoncello.Text = "Limoncello";
            // 
            // lblGaseosaCocaColaSinAzucar300ml
            // 
            this.lblGaseosaCocaColaSinAzucar300ml.AutoSize = true;
            this.lblGaseosaCocaColaSinAzucar300ml.Location = new System.Drawing.Point(59, 82);
            this.lblGaseosaCocaColaSinAzucar300ml.Name = "lblGaseosaCocaColaSinAzucar300ml";
            this.lblGaseosaCocaColaSinAzucar300ml.Size = new System.Drawing.Size(186, 13);
            this.lblGaseosaCocaColaSinAzucar300ml.TabIndex = 75;
            this.lblGaseosaCocaColaSinAzucar300ml.Text = "Gaseosa Coca-Cola Sin Azúcar 300ml";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(59, 271);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(186, 142);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 74;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(299, 98);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(181, 108);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 73;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(550, 98);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(173, 108);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 72;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(299, 271);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(181, 142);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 71;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(59, 98);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(186, 108);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 70;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 453);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 69;
            this.pictureBox1.TabStop = false;
            // 
            // txtnombreb
            // 
            this.txtnombreb.Location = new System.Drawing.Point(560, 241);
            this.txtnombreb.Name = "txtnombreb";
            this.txtnombreb.Size = new System.Drawing.Size(46, 20);
            this.txtnombreb.TabIndex = 91;
            // 
            // txtvalortotalb
            // 
            this.txtvalortotalb.Location = new System.Drawing.Point(714, 241);
            this.txtvalortotalb.Name = "txtvalortotalb";
            this.txtvalortotalb.Size = new System.Drawing.Size(46, 20);
            this.txtvalortotalb.TabIndex = 92;
            // 
            // txtvalorunidadb
            // 
            this.txtvalorunidadb.Location = new System.Drawing.Point(664, 241);
            this.txtvalorunidadb.Name = "txtvalorunidadb";
            this.txtvalorunidadb.Size = new System.Drawing.Size(46, 20);
            this.txtvalorunidadb.TabIndex = 93;
            // 
            // txtcantidadb
            // 
            this.txtcantidadb.Location = new System.Drawing.Point(612, 241);
            this.txtcantidadb.Name = "txtcantidadb";
            this.txtcantidadb.Size = new System.Drawing.Size(46, 20);
            this.txtcantidadb.TabIndex = 94;
            // 
            // txttotalapagare
            // 
            this.txttotalapagare.Location = new System.Drawing.Point(559, 289);
            this.txttotalapagare.Name = "txttotalapagare";
            this.txttotalapagare.Size = new System.Drawing.Size(46, 20);
            this.txttotalapagare.TabIndex = 95;
            // 
            // Bebidas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txttotalapagare);
            this.Controls.Add(this.txtcantidadb);
            this.Controls.Add(this.txtvalorunidadb);
            this.Controls.Add(this.txtvalortotalb);
            this.Controls.Add(this.txtnombreb);
            this.Controls.Add(this.btnAgregarBebidas);
            this.Controls.Add(this.ndCocacola);
            this.Controls.Add(this.ndLimoncello);
            this.Controls.Add(this.ndJugodePiñaconHierbabuena);
            this.Controls.Add(this.ndJugodeFrutosAmarillos);
            this.Controls.Add(this.ndJugodeFrutosRojos);
            this.Controls.Add(this.lblPrecioJugodeFrutosRojos);
            this.Controls.Add(this.lblPrecioJugodeFrutosAmarillos);
            this.Controls.Add(this.lblPrecioJugodePiñaconHierbabuena);
            this.Controls.Add(this.lblPrecioLimoncello);
            this.Controls.Add(this.lblPrecioGaseosaCocaColaSinAzucar);
            this.Controls.Add(this.lblJugodeFrutosRojos);
            this.Controls.Add(this.lblJugodeFrutosAmarillos);
            this.Controls.Add(this.lblJugodePiñaconHierbabuena);
            this.Controls.Add(this.lblLimoncello);
            this.Controls.Add(this.lblGaseosaCocaColaSinAzucar300ml);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Bebidas";
            this.Text = "Bebidas";
            this.Load += new System.EventHandler(this.Bebidas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ndCocacola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndLimoncello)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndJugodePiñaconHierbabuena)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndJugodeFrutosAmarillos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndJugodeFrutosRojos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAgregarBebidas;
        private System.Windows.Forms.NumericUpDown ndCocacola;
        private System.Windows.Forms.NumericUpDown ndLimoncello;
        private System.Windows.Forms.NumericUpDown ndJugodePiñaconHierbabuena;
        private System.Windows.Forms.NumericUpDown ndJugodeFrutosAmarillos;
        private System.Windows.Forms.NumericUpDown ndJugodeFrutosRojos;
        private System.Windows.Forms.Label lblPrecioJugodeFrutosRojos;
        private System.Windows.Forms.Label lblPrecioJugodeFrutosAmarillos;
        private System.Windows.Forms.Label lblPrecioJugodePiñaconHierbabuena;
        private System.Windows.Forms.Label lblPrecioLimoncello;
        private System.Windows.Forms.Label lblPrecioGaseosaCocaColaSinAzucar;
        private System.Windows.Forms.Label lblJugodeFrutosRojos;
        private System.Windows.Forms.Label lblJugodeFrutosAmarillos;
        private System.Windows.Forms.Label lblJugodePiñaconHierbabuena;
        private System.Windows.Forms.Label lblLimoncello;
        private System.Windows.Forms.Label lblGaseosaCocaColaSinAzucar300ml;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtnombreb;
        private System.Windows.Forms.TextBox txtvalortotalb;
        private System.Windows.Forms.TextBox txtvalorunidadb;
        private System.Windows.Forms.TextBox txtcantidadb;
        private System.Windows.Forms.TextBox txttotalapagare;
    }
}