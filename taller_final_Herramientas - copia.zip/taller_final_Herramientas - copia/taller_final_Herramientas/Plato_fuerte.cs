﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace taller_final_Herramientas
{
    public partial class Plato_fuerte : Form
    {
       

        private void Plato_fuerte_Load(object sender, EventArgs e)
        {

        }

        public Plato_fuerte()
        {
            InitializeComponent();
        }

        private void btnAgregarPlatoFuerte_Click(object sender, EventArgs e)
        {
             decimal cantidadn=0, valorunidadn=0, valortotaln = 0,totalp=0;
             string nombreproducton="";

            if (ndRisottoCarbonara.Value > 0)
                {
                nombreproducton += lblRisottoCarbonara.Text + ", \r\n";
                txtvaloru.Text += lblPrecioRisottoCarbonara.Text + "\r\n";
                valorunidadn = Convert.ToDecimal(lblPrecioRisottoCarbonara.Text);
                valortotaln = valorunidadn * ndRisottoCarbonara.Value;
                totalp = totalp + valortotaln;
                cantidadn = ndRisottoCarbonara.Value;
                txtcant.Text += cantidadn.ToString() + ", \r\n";
                txtvalort.Text += valortotaln.ToString() + ", \r\n";
            }

            if (ndPastaAlfredoconSalmón.Value > 0)
            {
            nombreproducton += lblPastaAlfredoconSalmón.Text + ", \r\n";
            txtvaloru.Text += lblPrecioPastaAlfredoconSalmón.Text + ", \r\n";
            valorunidadn = Convert.ToDecimal(lblPrecioPastaAlfredoconSalmón.Text);
            valortotaln = valorunidadn * ndPastaAlfredoconSalmón.Value;
            totalp = totalp + valortotaln;
            cantidadn = ndPastaAlfredoconSalmón.Value;
            txtcant.Text += cantidadn.ToString() + ", \r\n";
            txtvalort.Text += valortotaln.ToString() + ", \r\n";
            }

            if (ndPastaCarbonara.Value > 0)
            {
                nombreproducton += lblPastaCarbonara.Text + ", \r\n";
                txtvaloru.Text += lblPrecioPastaCarbonara.Text + ", \r\n";
                valorunidadn = Convert.ToDecimal(lblPrecioPastaCarbonara.Text);
                valortotaln = valorunidadn * ndPastaCarbonara.Value;
                totalp = totalp + valortotaln;
                cantidadn = ndPastaCarbonara.Value;
                txtcant.Text += cantidadn.ToString() + ", \r\n";
                txtvalort.Text += valortotaln.ToString() + ", \r\n";

            }



            if (ndLasagnaVegetariana.Value > 0)
            {
                nombreproducton += lblLasagnaVegetariana.Text + ", \r\n";
                txtvaloru.Text += lblPrecioLasagnaVegetariana.Text + ", \r\n";
                valorunidadn = Convert.ToDecimal(lblPrecioLasagnaVegetariana.Text);
                valortotaln = valorunidadn * ndLasagnaVegetariana.Value;
                totalp = totalp + valortotaln;
                cantidadn = ndLasagnaVegetariana.Value;
                txtcant.Text += cantidadn.ToString() + ", \r\n";
                txtvalort.Text += valortotaln.ToString() + ", \r\n";

            }


            if (ndPastadelaHuerta.Value > 0)
            {
                nombreproducton += lblPastadelaHuerta.Text + ", \r\n";
                txtvaloru.Text += lblPrecioPastadelaHuerta.Text + ", \r\n";
                valorunidadn = Convert.ToDecimal(lblPrecioPastadelaHuerta.Text);
                valortotaln = valorunidadn * ndPastadelaHuerta.Value;
                totalp = totalp + valortotaln;
                cantidadn = ndPastadelaHuerta.Value;
                txtcant.Text += cantidadn.ToString() + ", \r\n";
                txtvalort.Text +=valortotaln.ToString() + ", \r\n";
            }

            txtnom.Text = nombreproducton;
            txttotalp.Text = totalp.ToString();

            Menu mi_menu = new Menu();
            mi_menu.Nombreproductom = txtnom.Text;
            mi_menu.Cantidadm = txtcant.Text;
            mi_menu.Valorunidadm = txtvaloru.Text;
            mi_menu.Valortotalm = txtvalort.Text;


        }

        private void txtnom_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcant_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtvaloru_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtvalort_TextChanged(object sender, EventArgs e)
        {

        }

        private void txttotalp_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
