﻿namespace taller_final_Herramientas
{
    partial class Postres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Postres));
            this.btnAgregarPostres = new System.Windows.Forms.Button();
            this.ndTiramisu = new System.Windows.Forms.NumericUpDown();
            this.ndGalleta = new System.Windows.Forms.NumericUpDown();
            this.ndTartaleta = new System.Windows.Forms.NumericUpDown();
            this.ndBrownie = new System.Windows.Forms.NumericUpDown();
            this.ndCheesecake = new System.Windows.Forms.NumericUpDown();
            this.lblPrecioCheesecake = new System.Windows.Forms.Label();
            this.lblPrecioBrownie = new System.Windows.Forms.Label();
            this.lblPrecioTartaleta = new System.Windows.Forms.Label();
            this.lblPrecioGalleta = new System.Windows.Forms.Label();
            this.lblPrecioTiramisu = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblCheesecake = new System.Windows.Forms.Label();
            this.lblBrownie = new System.Windows.Forms.Label();
            this.lblTartaleta = new System.Windows.Forms.Label();
            this.lblGalleta = new System.Windows.Forms.Label();
            this.lblTiramisú = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtcantidadp = new System.Windows.Forms.TextBox();
            this.txtnombrep = new System.Windows.Forms.TextBox();
            this.txtvalortotalp = new System.Windows.Forms.TextBox();
            this.txtvalorunidadp = new System.Windows.Forms.TextBox();
            this.txttotalpagarp = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.ndTiramisu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndGalleta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndTartaleta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndBrownie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndCheesecake)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAgregarPostres
            // 
            this.btnAgregarPostres.Location = new System.Drawing.Point(565, 349);
            this.btnAgregarPostres.Name = "btnAgregarPostres";
            this.btnAgregarPostres.Size = new System.Drawing.Size(119, 52);
            this.btnAgregarPostres.TabIndex = 85;
            this.btnAgregarPostres.Text = "Agregar al carrito";
            this.btnAgregarPostres.UseVisualStyleBackColor = true;
            this.btnAgregarPostres.Click += new System.EventHandler(this.btnAgregarPostres_Click);
            // 
            // ndTiramisu
            // 
            this.ndTiramisu.Location = new System.Drawing.Point(187, 200);
            this.ndTiramisu.Name = "ndTiramisu";
            this.ndTiramisu.Size = new System.Drawing.Size(37, 20);
            this.ndTiramisu.TabIndex = 84;
            // 
            // ndGalleta
            // 
            this.ndGalleta.Location = new System.Drawing.Point(427, 200);
            this.ndGalleta.Name = "ndGalleta";
            this.ndGalleta.Size = new System.Drawing.Size(37, 20);
            this.ndGalleta.TabIndex = 83;
            // 
            // ndTartaleta
            // 
            this.ndTartaleta.Location = new System.Drawing.Point(690, 200);
            this.ndTartaleta.Name = "ndTartaleta";
            this.ndTartaleta.Size = new System.Drawing.Size(37, 20);
            this.ndTartaleta.TabIndex = 82;
            // 
            // ndBrownie
            // 
            this.ndBrownie.Location = new System.Drawing.Point(182, 418);
            this.ndBrownie.Name = "ndBrownie";
            this.ndBrownie.Size = new System.Drawing.Size(37, 20);
            this.ndBrownie.TabIndex = 81;
            // 
            // ndCheesecake
            // 
            this.ndCheesecake.Location = new System.Drawing.Point(425, 396);
            this.ndCheesecake.Name = "ndCheesecake";
            this.ndCheesecake.Size = new System.Drawing.Size(37, 20);
            this.ndCheesecake.TabIndex = 80;
            // 
            // lblPrecioCheesecake
            // 
            this.lblPrecioCheesecake.AutoSize = true;
            this.lblPrecioCheesecake.Location = new System.Drawing.Point(429, 347);
            this.lblPrecioCheesecake.Name = "lblPrecioCheesecake";
            this.lblPrecioCheesecake.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioCheesecake.TabIndex = 79;
            this.lblPrecioCheesecake.Text = "16700";
            // 
            // lblPrecioBrownie
            // 
            this.lblPrecioBrownie.AutoSize = true;
            this.lblPrecioBrownie.Location = new System.Drawing.Point(184, 349);
            this.lblPrecioBrownie.Name = "lblPrecioBrownie";
            this.lblPrecioBrownie.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioBrownie.TabIndex = 78;
            this.lblPrecioBrownie.Text = "15700";
            // 
            // lblPrecioTartaleta
            // 
            this.lblPrecioTartaleta.AutoSize = true;
            this.lblPrecioTartaleta.Location = new System.Drawing.Point(690, 153);
            this.lblPrecioTartaleta.Name = "lblPrecioTartaleta";
            this.lblPrecioTartaleta.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioTartaleta.TabIndex = 77;
            this.lblPrecioTartaleta.Text = "14600";
            // 
            // lblPrecioGalleta
            // 
            this.lblPrecioGalleta.AutoSize = true;
            this.lblPrecioGalleta.Location = new System.Drawing.Point(427, 151);
            this.lblPrecioGalleta.Name = "lblPrecioGalleta";
            this.lblPrecioGalleta.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioGalleta.TabIndex = 76;
            this.lblPrecioGalleta.Text = "18300";
            // 
            // lblPrecioTiramisu
            // 
            this.lblPrecioTiramisu.AutoSize = true;
            this.lblPrecioTiramisu.Location = new System.Drawing.Point(187, 151);
            this.lblPrecioTiramisu.Name = "lblPrecioTiramisu";
            this.lblPrecioTiramisu.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioTiramisu.TabIndex = 75;
            this.lblPrecioTiramisu.Text = "18900";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(278, 347);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(143, 69);
            this.textBox5.TabIndex = 74;
            this.textBox5.Text = "Postre de queso con base de galleta bañado con confitura de frutos rojos.";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(38, 347);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(143, 91);
            this.textBox4.TabIndex = 73;
            this.textBox4.Text = "Bizcocho de chocolate melcochudo que es crujiente por fuera y suave por dentro, e" +
    "stá elaborado con chocolate semi amargo, horneado sobre una salsa de arequipe, a" +
    "compañado de helado de vainilla.";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(541, 151);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(143, 69);
            this.textBox3.TabIndex = 72;
            this.textBox3.Text = "Crocante tarta de banano, acompañada de salsa de arequipe, caramelo y helado de v" +
    "ainilla.";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(278, 151);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(143, 69);
            this.textBox2.TabIndex = 71;
            this.textBox2.Text = "Deliciosa mezcla de galleta, café y trozos de chocolate, horneada al momento. aco" +
    "mpañada de helado de vainilla con salsa de frutos rojos.";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(38, 151);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(143, 69);
            this.textBox1.TabIndex = 70;
            this.textBox1.Text = "Postre italiano de contextura cremosa humedecida con café decorado con cocoa";
            // 
            // lblCheesecake
            // 
            this.lblCheesecake.AutoSize = true;
            this.lblCheesecake.Location = new System.Drawing.Point(281, 234);
            this.lblCheesecake.Name = "lblCheesecake";
            this.lblCheesecake.Size = new System.Drawing.Size(144, 13);
            this.lblCheesecake.TabIndex = 69;
            this.lblCheesecake.Text = "Cheesecake de Frutos Rojos";
            // 
            // lblBrownie
            // 
            this.lblBrownie.AutoSize = true;
            this.lblBrownie.Location = new System.Drawing.Point(35, 234);
            this.lblBrownie.Name = "lblBrownie";
            this.lblBrownie.Size = new System.Drawing.Size(111, 13);
            this.lblBrownie.TabIndex = 68;
            this.lblBrownie.Text = "Brownie con Arequipe";
            // 
            // lblTartaleta
            // 
            this.lblTartaleta.AutoSize = true;
            this.lblTartaleta.Location = new System.Drawing.Point(538, 70);
            this.lblTartaleta.Name = "lblTartaleta";
            this.lblTartaleta.Size = new System.Drawing.Size(157, 13);
            this.lblTartaleta.TabIndex = 67;
            this.lblTartaleta.Text = "Tartaleta de Banano y Arequipe";
            // 
            // lblGalleta
            // 
            this.lblGalleta.AutoSize = true;
            this.lblGalleta.Location = new System.Drawing.Point(279, 61);
            this.lblGalleta.Name = "lblGalleta";
            this.lblGalleta.Size = new System.Drawing.Size(70, 13);
            this.lblGalleta.TabIndex = 66;
            this.lblGalleta.Text = "Galleta Moka";
            // 
            // lblTiramisú
            // 
            this.lblTiramisú.AutoSize = true;
            this.lblTiramisú.Location = new System.Drawing.Point(38, 61);
            this.lblTiramisú.Name = "lblTiramisú";
            this.lblTiramisú.Size = new System.Drawing.Size(46, 13);
            this.lblTiramisú.TabIndex = 65;
            this.lblTiramisú.Text = "Tiramisú";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(38, 250);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(139, 91);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 64;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(278, 77);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(143, 77);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 63;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(541, 86);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(143, 68);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 62;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(278, 250);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(143, 91);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 61;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(38, 77);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(139, 77);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 60;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(797, 447);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 59;
            this.pictureBox1.TabStop = false;
            // 
            // txtcantidadp
            // 
            this.txtcantidadp.Location = new System.Drawing.Point(528, 242);
            this.txtcantidadp.Name = "txtcantidadp";
            this.txtcantidadp.Size = new System.Drawing.Size(66, 20);
            this.txtcantidadp.TabIndex = 86;
            // 
            // txtnombrep
            // 
            this.txtnombrep.Location = new System.Drawing.Point(456, 242);
            this.txtnombrep.Name = "txtnombrep";
            this.txtnombrep.Size = new System.Drawing.Size(66, 20);
            this.txtnombrep.TabIndex = 87;
            // 
            // txtvalortotalp
            // 
            this.txtvalortotalp.Location = new System.Drawing.Point(672, 242);
            this.txtvalortotalp.Name = "txtvalortotalp";
            this.txtvalortotalp.Size = new System.Drawing.Size(66, 20);
            this.txtvalortotalp.TabIndex = 88;
            // 
            // txtvalorunidadp
            // 
            this.txtvalorunidadp.Location = new System.Drawing.Point(600, 242);
            this.txtvalorunidadp.Name = "txtvalorunidadp";
            this.txtvalorunidadp.Size = new System.Drawing.Size(66, 20);
            this.txtvalorunidadp.TabIndex = 89;
            // 
            // txttotalpagarp
            // 
            this.txttotalpagarp.Location = new System.Drawing.Point(528, 291);
            this.txttotalpagarp.Name = "txttotalpagarp";
            this.txttotalpagarp.Size = new System.Drawing.Size(66, 20);
            this.txttotalpagarp.TabIndex = 90;
            // 
            // Postres
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 450);
            this.Controls.Add(this.txttotalpagarp);
            this.Controls.Add(this.txtvalorunidadp);
            this.Controls.Add(this.txtvalortotalp);
            this.Controls.Add(this.txtnombrep);
            this.Controls.Add(this.txtcantidadp);
            this.Controls.Add(this.btnAgregarPostres);
            this.Controls.Add(this.ndTiramisu);
            this.Controls.Add(this.ndGalleta);
            this.Controls.Add(this.ndTartaleta);
            this.Controls.Add(this.ndBrownie);
            this.Controls.Add(this.ndCheesecake);
            this.Controls.Add(this.lblPrecioCheesecake);
            this.Controls.Add(this.lblPrecioBrownie);
            this.Controls.Add(this.lblPrecioTartaleta);
            this.Controls.Add(this.lblPrecioGalleta);
            this.Controls.Add(this.lblPrecioTiramisu);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblCheesecake);
            this.Controls.Add(this.lblBrownie);
            this.Controls.Add(this.lblTartaleta);
            this.Controls.Add(this.lblGalleta);
            this.Controls.Add(this.lblTiramisú);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Postres";
            this.Text = "Postres";
            ((System.ComponentModel.ISupportInitialize)(this.ndTiramisu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndGalleta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndTartaleta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndBrownie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndCheesecake)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAgregarPostres;
        private System.Windows.Forms.NumericUpDown ndTiramisu;
        private System.Windows.Forms.NumericUpDown ndGalleta;
        private System.Windows.Forms.NumericUpDown ndTartaleta;
        private System.Windows.Forms.NumericUpDown ndBrownie;
        private System.Windows.Forms.NumericUpDown ndCheesecake;
        private System.Windows.Forms.Label lblPrecioCheesecake;
        private System.Windows.Forms.Label lblPrecioBrownie;
        private System.Windows.Forms.Label lblPrecioTartaleta;
        private System.Windows.Forms.Label lblPrecioGalleta;
        private System.Windows.Forms.Label lblPrecioTiramisu;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblCheesecake;
        private System.Windows.Forms.Label lblBrownie;
        private System.Windows.Forms.Label lblTartaleta;
        private System.Windows.Forms.Label lblGalleta;
        private System.Windows.Forms.Label lblTiramisú;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtcantidadp;
        private System.Windows.Forms.TextBox txtnombrep;
        private System.Windows.Forms.TextBox txtvalortotalp;
        private System.Windows.Forms.TextBox txtvalorunidadp;
        private System.Windows.Forms.TextBox txttotalpagarp;
    }
}