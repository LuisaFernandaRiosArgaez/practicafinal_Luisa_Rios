﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace taller_final_Herramientas
{
    public partial class Bebidas : Form
    {

        public decimal cantidadb, valorunidadb, valortotalb;
        public string nombreproductob;
        public Bebidas()
        {
            InitializeComponent();
        }

        private void Bebidas_Load(object sender, EventArgs e)
        {

        }

        private void btnAgregarBebidas_Click(object sender, EventArgs e)
        {
         decimal cantidadb, valorunidadb, valortotalb, valortotalapagarb=0;
        string nombreproductob="";

        if (ndCocacola.Value > 0)
            {

                nombreproductob += lblGaseosaCocaColaSinAzucar300ml.Text + ", \r\n";
                txtvalorunidadb.Text += lblPrecioGaseosaCocaColaSinAzucar.Text + ", \r\n";
                valorunidadb = Convert.ToDecimal(lblPrecioGaseosaCocaColaSinAzucar.Text);
                valortotalb = valorunidadb * ndCocacola.Value;
                valortotalapagarb = valortotalapagarb + valortotalb;
                cantidadb = ndCocacola.Value;
                txtcantidadb.Text += cantidadb.ToString() + ", \r\n";
                txtvalortotalb.Text += valortotalb.ToString() + ", \r\n";
            }

            if (ndLimoncello.Value > 0)
            {

                nombreproductob += lblLimoncello.Text + ", \r\n";
                txtvalorunidadb.Text += lblPrecioLimoncello.Text + ", \r\n";
                valorunidadb = Convert.ToDecimal(lblPrecioLimoncello.Text);
                valortotalb = valorunidadb * ndLimoncello.Value;
                valortotalapagarb = valortotalapagarb + valortotalb;
                cantidadb = ndLimoncello.Value;
                txtcantidadb.Text += cantidadb.ToString() + ", \r\n";
                txtvalortotalb.Text += valortotalb.ToString() + ", \r\n";
            }
            
            if (ndJugodePiñaconHierbabuena.Value > 0)
            {

                nombreproductob += lblJugodePiñaconHierbabuena.Text + ", \r\n";
                txtvalorunidadb.Text += lblPrecioJugodePiñaconHierbabuena.Text + ", \r\n";
                valorunidadb = Convert.ToDecimal(lblPrecioJugodePiñaconHierbabuena.Text);
                valortotalb = valorunidadb * ndJugodePiñaconHierbabuena.Value;
                valortotalapagarb = valortotalapagarb + valortotalb;
                cantidadb = ndJugodePiñaconHierbabuena.Value;
                txtcantidadb.Text += cantidadb.ToString() + ", \r\n";
                txtvalortotalb.Text += valortotalb.ToString() + ", \r\n";
            }
           if (ndJugodeFrutosAmarillos.Value > 0)
            {

                nombreproductob += lblJugodeFrutosAmarillos.Text + ", \r\n";
                txtvalorunidadb.Text += lblPrecioJugodeFrutosAmarillos.Text + ", \r\n";
                valorunidadb = Convert.ToDecimal(lblPrecioJugodeFrutosAmarillos.Text);
                valortotalb = valorunidadb * ndJugodeFrutosAmarillos.Value;
                valortotalapagarb = valortotalapagarb + valortotalb;
                cantidadb = ndJugodeFrutosAmarillos.Value;
                txtcantidadb.Text += cantidadb.ToString() + ", \r\n";
                txtvalortotalb.Text += valortotalb.ToString() + ", \r\n";
            }

            if (ndJugodeFrutosRojos.Value > 0)
            {

                nombreproductob += lblJugodeFrutosRojos.Text + ", \r\n";
                txtvalorunidadb.Text += lblPrecioJugodeFrutosRojos.Text + ", \r\n";
                valorunidadb = Convert.ToDecimal(lblPrecioJugodeFrutosRojos.Text);
                valortotalb = valorunidadb * ndJugodeFrutosRojos.Value;
                valortotalapagarb = valortotalapagarb + valortotalb;
                cantidadb = ndJugodeFrutosRojos.Value;
                txtcantidadb.Text += cantidadb.ToString() + ", \r\n";
                txtvalortotalb.Text += valortotalb.ToString() + ", \r\n";
            }

            txtnombreb.Text = nombreproductob;
            txtvalortotalb.Text = valortotalapagarb.ToString();

            Menu mi_menu = new Menu();
            mi_menu.Nombreproductom = txtnombreb.Text;
            mi_menu.Cantidadm = txtcantidadb.Text;
            mi_menu.Valorunidadm = txtvalorunidadb.Text;
            mi_menu.Valortotalm = txtvalortotalb.Text;


        }
    }
}
