﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace taller_final_Herramientas
{
    public partial class Menu : Form
    {

        public string nombreproductom, cantidadm, valorunidadm, valortotalm;
        public Menu()
        {
            InitializeComponent();
        }

        public string Nombreproductom
        {
            set
            {
                nombreproductom = value;
                txtnombrem.Text = nombreproductom;
            }
        }
        public string Cantidadm
        {
            set
            {
                cantidadm = value;
                txtcantidadm.Text = cantidadm;
            }
        }
        public string Valorunidadm
        {
            set
            {
                valorunidadm = value;
                txtvalorunidadm.Text = valorunidadm;
            }
        }
        public string Valortotalm
        {
            set
            {
                valortotalm = value;
                txttotalm.Text = valortotalm;
            }
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void btnEntradas_Click(object sender, EventArgs e)
        {
            Entradas Entradas = new Entradas();
            Entradas.Show();
        }

        private void btnPlatofuerte_Click(object sender, EventArgs e)
        {
            Plato_fuerte Plato_fuerte = new Plato_fuerte();
            Plato_fuerte.Show();    
        }

        private void btnPostres_Click(object sender, EventArgs e)
        {
            Postres Postres = new Postres();
            Postres.Show();
        }

        private void btnBebidas_Click(object sender, EventArgs e)
        {
            Bebidas Bebidas = new Bebidas();
            Bebidas.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Carrito Mi_Carrito = new Carrito();
            Mi_Carrito.Nombreproductoc = nombreproductom;
            Mi_Carrito.cantidadc = cantidadm;
            Mi_Carrito.valorunidadc = valorunidadm;
            Mi_Carrito.valortotalc = valortotalm; 
            Mi_Carrito.Show();
        }
    }
}
