﻿namespace taller_final_Herramientas
{
    partial class Entradas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Entradas));
            this.btnAgregarEntrada = new System.Windows.Forms.Button();
            this.ndPapialpaCrujiente = new System.Windows.Forms.NumericUpDown();
            this.lblPrecioPapialpaCrujiente = new System.Windows.Forms.Label();
            this.ndCarpacciodePulpo = new System.Windows.Forms.NumericUpDown();
            this.ndMozarellaCapresse = new System.Windows.Forms.NumericUpDown();
            this.ndPulpoEspecialdelaCasa = new System.Windows.Forms.NumericUpDown();
            this.ndCarpacciodeLomitoalaPimienta = new System.Windows.Forms.NumericUpDown();
            this.ndCalamaresalaRomana = new System.Windows.Forms.NumericUpDown();
            this.lblPrecioCalamaresalaRomana = new System.Windows.Forms.Label();
            this.lblPrecioCarpacciodeLomitoalaPimienta = new System.Windows.Forms.Label();
            this.LBLprecio1 = new System.Windows.Forms.Label();
            this.lblPrecioMozarellaCapresse = new System.Windows.Forms.Label();
            this.lblPrecioCarpacciodePulpo = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblPapialpaCrujiente = new System.Windows.Forms.Label();
            this.lblCalamaresalaRomana = new System.Windows.Forms.Label();
            this.lblCarpacciodeLomitoalaPimienta = new System.Windows.Forms.Label();
            this.lblPulpoEspecialdelaCasa = new System.Windows.Forms.Label();
            this.lblMozarellaCapresse = new System.Windows.Forms.Label();
            this.lblCarpacciodePulpo = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.txtnombree = new System.Windows.Forms.TextBox();
            this.txttotalapagare = new System.Windows.Forms.TextBox();
            this.txtvalortotale = new System.Windows.Forms.TextBox();
            this.txtvalorunidade = new System.Windows.Forms.TextBox();
            this.txtcantidade = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.ndPapialpaCrujiente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndCarpacciodePulpo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndMozarellaCapresse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndPulpoEspecialdelaCasa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndCarpacciodeLomitoalaPimienta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndCalamaresalaRomana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAgregarEntrada
            // 
            this.btnAgregarEntrada.Location = new System.Drawing.Point(533, 11);
            this.btnAgregarEntrada.Name = "btnAgregarEntrada";
            this.btnAgregarEntrada.Size = new System.Drawing.Size(153, 38);
            this.btnAgregarEntrada.TabIndex = 102;
            this.btnAgregarEntrada.Text = "Agregar al carrito";
            this.btnAgregarEntrada.UseVisualStyleBackColor = true;
            this.btnAgregarEntrada.Click += new System.EventHandler(this.btnAgregarEntrada_Click);
            // 
            // ndPapialpaCrujiente
            // 
            this.ndPapialpaCrujiente.Location = new System.Drawing.Point(682, 408);
            this.ndPapialpaCrujiente.Name = "ndPapialpaCrujiente";
            this.ndPapialpaCrujiente.Size = new System.Drawing.Size(37, 20);
            this.ndPapialpaCrujiente.TabIndex = 101;
            // 
            // lblPrecioPapialpaCrujiente
            // 
            this.lblPrecioPapialpaCrujiente.AutoSize = true;
            this.lblPrecioPapialpaCrujiente.Location = new System.Drawing.Point(682, 359);
            this.lblPrecioPapialpaCrujiente.Name = "lblPrecioPapialpaCrujiente";
            this.lblPrecioPapialpaCrujiente.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioPapialpaCrujiente.TabIndex = 100;
            this.lblPrecioPapialpaCrujiente.Text = "23900";
            // 
            // ndCarpacciodePulpo
            // 
            this.ndCarpacciodePulpo.Location = new System.Drawing.Point(179, 212);
            this.ndCarpacciodePulpo.Name = "ndCarpacciodePulpo";
            this.ndCarpacciodePulpo.Size = new System.Drawing.Size(37, 20);
            this.ndCarpacciodePulpo.TabIndex = 99;
            // 
            // ndMozarellaCapresse
            // 
            this.ndMozarellaCapresse.Location = new System.Drawing.Point(419, 212);
            this.ndMozarellaCapresse.Name = "ndMozarellaCapresse";
            this.ndMozarellaCapresse.Size = new System.Drawing.Size(37, 20);
            this.ndMozarellaCapresse.TabIndex = 98;
            // 
            // ndPulpoEspecialdelaCasa
            // 
            this.ndPulpoEspecialdelaCasa.Location = new System.Drawing.Point(682, 212);
            this.ndPulpoEspecialdelaCasa.Name = "ndPulpoEspecialdelaCasa";
            this.ndPulpoEspecialdelaCasa.Size = new System.Drawing.Size(37, 20);
            this.ndPulpoEspecialdelaCasa.TabIndex = 97;
            // 
            // ndCarpacciodeLomitoalaPimienta
            // 
            this.ndCarpacciodeLomitoalaPimienta.Location = new System.Drawing.Point(179, 408);
            this.ndCarpacciodeLomitoalaPimienta.Name = "ndCarpacciodeLomitoalaPimienta";
            this.ndCarpacciodeLomitoalaPimienta.Size = new System.Drawing.Size(37, 20);
            this.ndCarpacciodeLomitoalaPimienta.TabIndex = 96;
            // 
            // ndCalamaresalaRomana
            // 
            this.ndCalamaresalaRomana.Location = new System.Drawing.Point(419, 408);
            this.ndCalamaresalaRomana.Name = "ndCalamaresalaRomana";
            this.ndCalamaresalaRomana.Size = new System.Drawing.Size(37, 20);
            this.ndCalamaresalaRomana.TabIndex = 95;
            // 
            // lblPrecioCalamaresalaRomana
            // 
            this.lblPrecioCalamaresalaRomana.AutoSize = true;
            this.lblPrecioCalamaresalaRomana.Location = new System.Drawing.Point(419, 359);
            this.lblPrecioCalamaresalaRomana.Name = "lblPrecioCalamaresalaRomana";
            this.lblPrecioCalamaresalaRomana.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioCalamaresalaRomana.TabIndex = 94;
            this.lblPrecioCalamaresalaRomana.Text = "29900";
            // 
            // lblPrecioCarpacciodeLomitoalaPimienta
            // 
            this.lblPrecioCarpacciodeLomitoalaPimienta.AutoSize = true;
            this.lblPrecioCarpacciodeLomitoalaPimienta.Location = new System.Drawing.Point(179, 359);
            this.lblPrecioCarpacciodeLomitoalaPimienta.Name = "lblPrecioCarpacciodeLomitoalaPimienta";
            this.lblPrecioCarpacciodeLomitoalaPimienta.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioCarpacciodeLomitoalaPimienta.TabIndex = 93;
            this.lblPrecioCarpacciodeLomitoalaPimienta.Text = "30900";
            // 
            // LBLprecio1
            // 
            this.LBLprecio1.AutoSize = true;
            this.LBLprecio1.Location = new System.Drawing.Point(679, 163);
            this.LBLprecio1.Name = "LBLprecio1";
            this.LBLprecio1.Size = new System.Drawing.Size(37, 13);
            this.LBLprecio1.TabIndex = 92;
            this.LBLprecio1.Text = "49900";
            // 
            // lblPrecioMozarellaCapresse
            // 
            this.lblPrecioMozarellaCapresse.AutoSize = true;
            this.lblPrecioMozarellaCapresse.Location = new System.Drawing.Point(416, 165);
            this.lblPrecioMozarellaCapresse.Name = "lblPrecioMozarellaCapresse";
            this.lblPrecioMozarellaCapresse.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioMozarellaCapresse.TabIndex = 91;
            this.lblPrecioMozarellaCapresse.Text = "29900";
            // 
            // lblPrecioCarpacciodePulpo
            // 
            this.lblPrecioCarpacciodePulpo.AutoSize = true;
            this.lblPrecioCarpacciodePulpo.Location = new System.Drawing.Point(179, 165);
            this.lblPrecioCarpacciodePulpo.Name = "lblPrecioCarpacciodePulpo";
            this.lblPrecioCarpacciodePulpo.Size = new System.Drawing.Size(37, 13);
            this.lblPrecioCarpacciodePulpo.TabIndex = 90;
            this.lblPrecioCarpacciodePulpo.Text = "41500";
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(533, 359);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(143, 69);
            this.textBox6.TabIndex = 89;
            this.textBox6.Text = "Dedos de queso papialpa empanizados en maní, hortalizas orgánicas, reducción de b" +
    "alsámico y moras.";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(270, 359);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(143, 69);
            this.textBox5.TabIndex = 88;
            this.textBox5.Text = "Anillos de calamar empanizados en panko, acompañados con cascos de limón y pomodo" +
    "ro de la casa.";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(30, 359);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(143, 69);
            this.textBox4.TabIndex = 87;
            this.textBox4.Text = "Finas láminas de solomito en costra de pimienta, queso parmesano, aceitunas verde" +
    "s, aceite de oliva, brotes orgánicos, pan fresco.";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(533, 163);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(143, 69);
            this.textBox3.TabIndex = 86;
            this.textBox3.Text = "Pulpo salteado en aceite de oliva, tomate cherry confitado, vino blanco, picadill" +
    "o de la casa, papa, hortalizas orgánicas, limón.";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(270, 163);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(143, 69);
            this.textBox2.TabIndex = 85;
            this.textBox2.Text = "Clásico italiano de queso mozzarella de búfala, tomates frescos, salsa pesto, ace" +
    "ite de oliva y reducción de balsámico.";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(30, 163);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(143, 69);
            this.textBox1.TabIndex = 84;
            this.textBox1.Text = "Finas láminas de pulpo fresco, brotes orgánicos, escamas de queso parmesano y may" +
    "onesa de la casa, acompañado de cascos de limón y pan fresco.";
            // 
            // lblPapialpaCrujiente
            // 
            this.lblPapialpaCrujiente.AutoSize = true;
            this.lblPapialpaCrujiente.Location = new System.Drawing.Point(530, 246);
            this.lblPapialpaCrujiente.Name = "lblPapialpaCrujiente";
            this.lblPapialpaCrujiente.Size = new System.Drawing.Size(92, 13);
            this.lblPapialpaCrujiente.TabIndex = 82;
            this.lblPapialpaCrujiente.Text = "Papialpa Crujiente";
            // 
            // lblCalamaresalaRomana
            // 
            this.lblCalamaresalaRomana.AutoSize = true;
            this.lblCalamaresalaRomana.Location = new System.Drawing.Point(267, 246);
            this.lblCalamaresalaRomana.Name = "lblCalamaresalaRomana";
            this.lblCalamaresalaRomana.Size = new System.Drawing.Size(119, 13);
            this.lblCalamaresalaRomana.TabIndex = 81;
            this.lblCalamaresalaRomana.Text = "Calamares a la Romana";
            // 
            // lblCarpacciodeLomitoalaPimienta
            // 
            this.lblCarpacciodeLomitoalaPimienta.AutoSize = true;
            this.lblCarpacciodeLomitoalaPimienta.Location = new System.Drawing.Point(27, 246);
            this.lblCarpacciodeLomitoalaPimienta.Name = "lblCarpacciodeLomitoalaPimienta";
            this.lblCarpacciodeLomitoalaPimienta.Size = new System.Drawing.Size(167, 13);
            this.lblCarpacciodeLomitoalaPimienta.TabIndex = 80;
            this.lblCarpacciodeLomitoalaPimienta.Text = "Carpaccio de Lomito a la Pimienta";
            // 
            // lblPulpoEspecialdelaCasa
            // 
            this.lblPulpoEspecialdelaCasa.AutoSize = true;
            this.lblPulpoEspecialdelaCasa.Location = new System.Drawing.Point(530, 82);
            this.lblPulpoEspecialdelaCasa.Name = "lblPulpoEspecialdelaCasa";
            this.lblPulpoEspecialdelaCasa.Size = new System.Drawing.Size(130, 13);
            this.lblPulpoEspecialdelaCasa.TabIndex = 79;
            this.lblPulpoEspecialdelaCasa.Text = "Pulpo Especial de la Casa";
            // 
            // lblMozarellaCapresse
            // 
            this.lblMozarellaCapresse.AutoSize = true;
            this.lblMozarellaCapresse.Location = new System.Drawing.Point(271, 73);
            this.lblMozarellaCapresse.Name = "lblMozarellaCapresse";
            this.lblMozarellaCapresse.Size = new System.Drawing.Size(99, 13);
            this.lblMozarellaCapresse.TabIndex = 78;
            this.lblMozarellaCapresse.Text = "Mozarella Capresse";
            // 
            // lblCarpacciodePulpo
            // 
            this.lblCarpacciodePulpo.AutoSize = true;
            this.lblCarpacciodePulpo.Location = new System.Drawing.Point(30, 73);
            this.lblCarpacciodePulpo.Name = "lblCarpacciodePulpo";
            this.lblCarpacciodePulpo.Size = new System.Drawing.Size(100, 13);
            this.lblCarpacciodePulpo.TabIndex = 77;
            this.lblCarpacciodePulpo.Text = "Carpaccio de Pulpo";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(30, 262);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(139, 91);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 76;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(270, 89);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(143, 77);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 75;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(533, 98);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(143, 68);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 74;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(533, 262);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(143, 91);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 73;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(270, 262);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(143, 91);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 72;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(30, 89);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(139, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 71;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(-1, -1);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(803, 452);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 83;
            this.pictureBox7.TabStop = false;
            // 
            // txtnombree
            // 
            this.txtnombree.Location = new System.Drawing.Point(223, 21);
            this.txtnombree.Name = "txtnombree";
            this.txtnombree.Size = new System.Drawing.Size(72, 20);
            this.txtnombree.TabIndex = 103;
            // 
            // txttotalapagare
            // 
            this.txttotalapagare.Location = new System.Drawing.Point(223, 47);
            this.txttotalapagare.Name = "txttotalapagare";
            this.txttotalapagare.Size = new System.Drawing.Size(100, 20);
            this.txttotalapagare.TabIndex = 104;
            // 
            // txtvalortotale
            // 
            this.txtvalortotale.Location = new System.Drawing.Point(456, 21);
            this.txtvalortotale.Name = "txtvalortotale";
            this.txtvalortotale.Size = new System.Drawing.Size(71, 20);
            this.txtvalortotale.TabIndex = 105;
            // 
            // txtvalorunidade
            // 
            this.txtvalorunidade.Location = new System.Drawing.Point(378, 21);
            this.txtvalorunidade.Name = "txtvalorunidade";
            this.txtvalorunidade.Size = new System.Drawing.Size(72, 20);
            this.txtvalorunidade.TabIndex = 106;
            // 
            // txtcantidade
            // 
            this.txtcantidade.Location = new System.Drawing.Point(301, 21);
            this.txtcantidade.Name = "txtcantidade";
            this.txtcantidade.Size = new System.Drawing.Size(71, 20);
            this.txtcantidade.TabIndex = 107;
            // 
            // Entradas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtcantidade);
            this.Controls.Add(this.txtvalorunidade);
            this.Controls.Add(this.txtvalortotale);
            this.Controls.Add(this.txttotalapagare);
            this.Controls.Add(this.txtnombree);
            this.Controls.Add(this.btnAgregarEntrada);
            this.Controls.Add(this.ndPapialpaCrujiente);
            this.Controls.Add(this.lblPrecioPapialpaCrujiente);
            this.Controls.Add(this.ndCarpacciodePulpo);
            this.Controls.Add(this.ndMozarellaCapresse);
            this.Controls.Add(this.ndPulpoEspecialdelaCasa);
            this.Controls.Add(this.ndCarpacciodeLomitoalaPimienta);
            this.Controls.Add(this.ndCalamaresalaRomana);
            this.Controls.Add(this.lblPrecioCalamaresalaRomana);
            this.Controls.Add(this.lblPrecioCarpacciodeLomitoalaPimienta);
            this.Controls.Add(this.LBLprecio1);
            this.Controls.Add(this.lblPrecioMozarellaCapresse);
            this.Controls.Add(this.lblPrecioCarpacciodePulpo);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblPapialpaCrujiente);
            this.Controls.Add(this.lblCalamaresalaRomana);
            this.Controls.Add(this.lblCarpacciodeLomitoalaPimienta);
            this.Controls.Add(this.lblPulpoEspecialdelaCasa);
            this.Controls.Add(this.lblMozarellaCapresse);
            this.Controls.Add(this.lblCarpacciodePulpo);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox7);
            this.Name = "Entradas";
            this.Text = "Entradas";
            this.Load += new System.EventHandler(this.Entradas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ndPapialpaCrujiente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndCarpacciodePulpo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndMozarellaCapresse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndPulpoEspecialdelaCasa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndCarpacciodeLomitoalaPimienta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ndCalamaresalaRomana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAgregarEntrada;
        private System.Windows.Forms.NumericUpDown ndPapialpaCrujiente;
        private System.Windows.Forms.Label lblPrecioPapialpaCrujiente;
        private System.Windows.Forms.NumericUpDown ndCarpacciodePulpo;
        private System.Windows.Forms.NumericUpDown ndMozarellaCapresse;
        private System.Windows.Forms.NumericUpDown ndPulpoEspecialdelaCasa;
        private System.Windows.Forms.NumericUpDown ndCarpacciodeLomitoalaPimienta;
        private System.Windows.Forms.NumericUpDown ndCalamaresalaRomana;
        private System.Windows.Forms.Label lblPrecioCalamaresalaRomana;
        private System.Windows.Forms.Label lblPrecioCarpacciodeLomitoalaPimienta;
        private System.Windows.Forms.Label LBLprecio1;
        private System.Windows.Forms.Label lblPrecioMozarellaCapresse;
        private System.Windows.Forms.Label lblPrecioCarpacciodePulpo;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblPapialpaCrujiente;
        private System.Windows.Forms.Label lblCalamaresalaRomana;
        private System.Windows.Forms.Label lblCarpacciodeLomitoalaPimienta;
        private System.Windows.Forms.Label lblPulpoEspecialdelaCasa;
        private System.Windows.Forms.Label lblMozarellaCapresse;
        private System.Windows.Forms.Label lblCarpacciodePulpo;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.TextBox txtnombree;
        private System.Windows.Forms.TextBox txttotalapagare;
        private System.Windows.Forms.TextBox txtvalortotale;
        private System.Windows.Forms.TextBox txtvalorunidade;
        private System.Windows.Forms.TextBox txtcantidade;
    }
}