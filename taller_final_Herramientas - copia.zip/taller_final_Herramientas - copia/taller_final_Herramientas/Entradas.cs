﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace taller_final_Herramientas
{
    public partial class Entradas : Form
    {

        public Entradas()
        {
            InitializeComponent();
        }

        private void Entradas_Load(object sender, EventArgs e)
        {
         
        }

        private void btnAgregarEntrada_Click(object sender, EventArgs e)
        {
            Carrito carrito = new Carrito();
            carrito.Show();

         decimal cantidade, valorunidade, valortotale, valortotalpagare=0;
         string nombreproductoe ="";

        if (ndCarpacciodePulpo.Value > 0)
            {

                nombreproductoe += lblCarpacciodePulpo.Text + ", \r\n";
                txtvalorunidade.Text += lblPrecioCarpacciodePulpo.Text + ", \r\n";
                valorunidade = Convert.ToDecimal(lblPrecioCarpacciodePulpo.Text);
                valortotale = valorunidade * ndCarpacciodePulpo.Value;
                valortotalpagare = valortotalpagare + valortotale;
                cantidade = ndCarpacciodePulpo.Value;
                txtcantidade.Text += cantidade.ToString() + ", \r\n";
                txtvalortotale.Text += valortotale.ToString() + ", \r\n";
            }


            if (ndMozarellaCapresse.Value > 0)
            {

                nombreproductoe += lblMozarellaCapresse.Text + ", \r\n";
                txtvalorunidade.Text += lblPrecioMozarellaCapresse.Text + ", \r\n";
                valorunidade = Convert.ToDecimal(lblPrecioMozarellaCapresse.Text);
                valortotale = valorunidade * ndMozarellaCapresse.Value;
                valortotalpagare = valortotalpagare + valortotale;
                cantidade = ndMozarellaCapresse.Value;
                txtcantidade.Text += cantidade.ToString() + ", \r\n";
                txtvalortotale.Text += valortotale.ToString() + ", \r\n";
            }

            if (ndPulpoEspecialdelaCasa.Value > 0)
            {

                nombreproductoe += lblPulpoEspecialdelaCasa.Text + ", \r\n";
                txtvalorunidade.Text += LBLprecio1.Text + ", \r\n";
                valorunidade = Convert.ToDecimal(LBLprecio1.Text);
                valortotale = valorunidade * ndPulpoEspecialdelaCasa.Value;
                valortotalpagare = valortotalpagare + valortotale;
                cantidade = ndPulpoEspecialdelaCasa.Value;
                txtcantidade.Text += cantidade.ToString() + ", \r\n";
                txtvalortotale.Text += valortotale.ToString() + ", \r\n";
            }

            if (ndCarpacciodeLomitoalaPimienta.Value > 0)
            {

                nombreproductoe += lblCarpacciodeLomitoalaPimienta.Text + ", \r\n";
                txtvalorunidade.Text += lblPrecioCarpacciodeLomitoalaPimienta.Text + ", \r\n";
                valorunidade = Convert.ToDecimal(lblPrecioCarpacciodeLomitoalaPimienta.Text);
                valortotale = valorunidade * ndCarpacciodeLomitoalaPimienta.Value;
                valortotalpagare = valortotalpagare + valortotale;
                cantidade = ndCarpacciodeLomitoalaPimienta.Value;
                txtcantidade.Text += cantidade.ToString() + ", \r\n";
                txtvalortotale.Text += valortotale.ToString() + ", \r\n";
            }

            if (ndCalamaresalaRomana.Value > 0)
            {

                nombreproductoe += lblCalamaresalaRomana.Text + ", \r\n";
                txtvalorunidade.Text += lblPrecioCalamaresalaRomana.Text + ", \r\n";
                valorunidade = Convert.ToDecimal(lblPrecioCalamaresalaRomana.Text);
                valortotale = valorunidade * ndCalamaresalaRomana.Value;
                valortotalpagare = valortotalpagare + valortotale;
                cantidade = ndCalamaresalaRomana.Value;
                txtcantidade.Text += cantidade.ToString() + ", \r\n";
                txtvalortotale.Text += valortotale.ToString() + ", \r\n";
            }

            if (ndPapialpaCrujiente.Value > 0)
            {

                nombreproductoe += lblPapialpaCrujiente.Text + ", \r\n";
                txtvalorunidade.Text += lblPrecioPapialpaCrujiente.Text + ", \r\n";
                valorunidade = Convert.ToDecimal(lblPrecioPapialpaCrujiente .Text);
                valortotale = valorunidade * ndPapialpaCrujiente.Value;
                valortotalpagare = valortotalpagare + valortotale;
                cantidade = ndPapialpaCrujiente.Value;
                txtcantidade.Text += cantidade.ToString() + ", \r\n";
                txtvalortotale.Text += valortotale.ToString() + ", \r\n";
            }
            txtnombree.Text = nombreproductoe;
            txttotalapagare.Text = valortotalpagare.ToString();

            Menu mi_menu = new Menu();
            mi_menu.Nombreproductom = txtnombree.Text;
            mi_menu.Cantidadm = txtcantidade.Text;
            mi_menu.Valorunidadm = txtvalorunidade.Text;
            mi_menu.Valortotalm = txtvalortotale.Text;
        }

    }
}
