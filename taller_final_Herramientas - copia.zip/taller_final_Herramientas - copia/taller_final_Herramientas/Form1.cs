﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace taller_final_Herramientas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text == "Luisa" && txtContraseña.Text == "1234")
            {
                Menu Mi_menu = new Menu();
                Mi_menu.Show();
            }
            else
            {
                MessageBox.Show("Usuario y contraseña incorrectos");
            }
        }
    }
}
