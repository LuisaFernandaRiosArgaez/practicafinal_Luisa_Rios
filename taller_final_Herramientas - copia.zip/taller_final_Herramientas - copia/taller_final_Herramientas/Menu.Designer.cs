﻿namespace taller_final_Herramientas
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.button5 = new System.Windows.Forms.Button();
            this.btnBebidas = new System.Windows.Forms.Button();
            this.btnPostres = new System.Windows.Forms.Button();
            this.btnPlatofuerte = new System.Windows.Forms.Button();
            this.btnEntradas = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txttotalm = new System.Windows.Forms.TextBox();
            this.txtvalorunidadm = new System.Windows.Forms.TextBox();
            this.txtcantidadm = new System.Windows.Forms.TextBox();
            this.txtnombrem = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(13, 273);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(150, 23);
            this.button5.TabIndex = 10;
            this.button5.Text = "Carrito";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnBebidas
            // 
            this.btnBebidas.Location = new System.Drawing.Point(13, 198);
            this.btnBebidas.Name = "btnBebidas";
            this.btnBebidas.Size = new System.Drawing.Size(150, 23);
            this.btnBebidas.TabIndex = 9;
            this.btnBebidas.Text = "Bebidas";
            this.btnBebidas.UseVisualStyleBackColor = true;
            this.btnBebidas.Click += new System.EventHandler(this.btnBebidas_Click);
            // 
            // btnPostres
            // 
            this.btnPostres.Location = new System.Drawing.Point(13, 157);
            this.btnPostres.Name = "btnPostres";
            this.btnPostres.Size = new System.Drawing.Size(150, 23);
            this.btnPostres.TabIndex = 8;
            this.btnPostres.Text = "Postres";
            this.btnPostres.UseVisualStyleBackColor = true;
            this.btnPostres.Click += new System.EventHandler(this.btnPostres_Click);
            // 
            // btnPlatofuerte
            // 
            this.btnPlatofuerte.Location = new System.Drawing.Point(13, 115);
            this.btnPlatofuerte.Name = "btnPlatofuerte";
            this.btnPlatofuerte.Size = new System.Drawing.Size(150, 23);
            this.btnPlatofuerte.TabIndex = 7;
            this.btnPlatofuerte.Text = "Platos Fuertes";
            this.btnPlatofuerte.UseVisualStyleBackColor = true;
            this.btnPlatofuerte.Click += new System.EventHandler(this.btnPlatofuerte_Click);
            // 
            // btnEntradas
            // 
            this.btnEntradas.Location = new System.Drawing.Point(13, 77);
            this.btnEntradas.Name = "btnEntradas";
            this.btnEntradas.Size = new System.Drawing.Size(150, 23);
            this.btnEntradas.TabIndex = 6;
            this.btnEntradas.Text = "Entradas";
            this.btnEntradas.UseVisualStyleBackColor = true;
            this.btnEntradas.Click += new System.EventHandler(this.btnEntradas_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(529, 306);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // txttotalm
            // 
            this.txttotalm.Location = new System.Drawing.Point(477, 77);
            this.txttotalm.Multiline = true;
            this.txttotalm.Name = "txttotalm";
            this.txttotalm.Size = new System.Drawing.Size(55, 215);
            this.txttotalm.TabIndex = 15;
            this.txttotalm.Visible = false;
            // 
            // txtvalorunidadm
            // 
            this.txtvalorunidadm.Location = new System.Drawing.Point(419, 77);
            this.txtvalorunidadm.Multiline = true;
            this.txtvalorunidadm.Name = "txtvalorunidadm";
            this.txtvalorunidadm.Size = new System.Drawing.Size(52, 215);
            this.txtvalorunidadm.TabIndex = 14;
            this.txtvalorunidadm.Visible = false;
            // 
            // txtcantidadm
            // 
            this.txtcantidadm.Location = new System.Drawing.Point(352, 77);
            this.txtcantidadm.Multiline = true;
            this.txtcantidadm.Name = "txtcantidadm";
            this.txtcantidadm.Size = new System.Drawing.Size(61, 215);
            this.txtcantidadm.TabIndex = 13;
            this.txtcantidadm.Visible = false;
            // 
            // txtnombrem
            // 
            this.txtnombrem.BackColor = System.Drawing.Color.White;
            this.txtnombrem.Location = new System.Drawing.Point(280, 77);
            this.txtnombrem.Multiline = true;
            this.txtnombrem.Name = "txtnombrem";
            this.txtnombrem.Size = new System.Drawing.Size(66, 215);
            this.txtnombrem.TabIndex = 12;
            this.txtnombrem.Visible = false;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 307);
            this.Controls.Add(this.txttotalm);
            this.Controls.Add(this.txtvalorunidadm);
            this.Controls.Add(this.txtcantidadm);
            this.Controls.Add(this.txtnombrem);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.btnBebidas);
            this.Controls.Add(this.btnPostres);
            this.Controls.Add(this.btnPlatofuerte);
            this.Controls.Add(this.btnEntradas);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnBebidas;
        private System.Windows.Forms.Button btnPostres;
        private System.Windows.Forms.Button btnPlatofuerte;
        private System.Windows.Forms.Button btnEntradas;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txttotalm;
        private System.Windows.Forms.TextBox txtvalorunidadm;
        private System.Windows.Forms.TextBox txtcantidadm;
        private System.Windows.Forms.TextBox txtnombrem;
    }
}